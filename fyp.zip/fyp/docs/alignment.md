# alignment

```python
def run_alignment(nodes1,nodes2,folder_path1,folder_path2,meta_list1,meta_list2):
    """
    Alignment two trees by dynmaic programming
    """
```

```python
def run_alignment_linear(nodes1,nodes2):
    """
    Alignment two trees by linear programming
    """

```

```python
class node:
    """
    Class of the node of the tree
    """

```

```python
class newnode:
    """
    Class of the aligned nodes by linear programming
    """

```

```python

class tree_alignment:
    """
    Class is used to perform tree alignment between two trees
    """
```

```python

def build_hyper_tree_from_folder(folder_path):
    """
    Build the tree from the folder
    """
```

```python

def search_tree(now,c,merge_list):
    """
    Merge the tree nodes according of the c
    """
```

```python

def find_path_root(now,dfs,path,dfs_node,f):
    """
    Find the path to the root
    """
```

```python

def find_indegree(lists,indegree):
    """
    Find the indegrees
    """
```
