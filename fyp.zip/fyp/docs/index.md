# Welcome to Alignment

## Alignment Library


## How to install Alignment


## How to use Alignment

    python run_sc.py -cp1 './datas/120/1/sample1_small.h5' -f1 "./datas/120/1/" -r1 52.48461374600768 -c1 0.1 -e1 10 -cp2 './datas/120/1/sample1_small.h5' -f2 "./datas/120/2/" -r2 52.43896907992145 -c2 0.1 -e2 10 --contin True --alignment 1 --resolution 1 --n_pca 100