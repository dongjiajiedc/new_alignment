python 3.8.16

Package	Version
argparse	1.1
matplotlib	3.6.2
networkx	2.8.2
numpy	1.23.5
pandas	1.4.4
plotly	5.11.0
scanpy	1.9.1
scipy	1.10.0
sklearn	1.2.1
torch	2.2.1


The key functions and instructions are in the demo.ipynb
